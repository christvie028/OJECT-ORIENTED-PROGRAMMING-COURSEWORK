/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.christ;

/**
 *
 * @author CHRISTVIE MALOLO
 */
public class Student extends User {

    public Student(String name, String email) {
        super(name, email);
    }

    @Override
    public void requestTransport() {
        System.out.println("Student " + getName() + " has requested transport.");
    }
}

