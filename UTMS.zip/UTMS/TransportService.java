/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.christ;

/**
 *
 * @author CHRISTVIE MALOLO
 */
public class TransportService {
    public void assignDriver (String vehicleType){
        System.out.println("Assigned driver based on vehicles type: " + vehicleType);
    }
    public void assignDriver( String vehicleType, String shifttime){
        System.out.println("Assigned driver based n vehicle type: "+ vehicleType + shifttime);
    }
}
