package com.mycompany.christ;


import com.mycompany.christ.Schedulable;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author CHRISTVIE MALOLO
 */
public class Van implements Schedulable{
    private String registrationNumber;
    
    public Van (String registrationNumber){
    this.registrationNumber =registrationNumber;
    }
    public String getRegistrationNumber(){
    return registrationNumber;
    }
    @Override
    public void schedule(){
    System.out.println("Van with reg no. " + registrationNumber + "scheduled.");
    }
}

