/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.christ;

/**
 *
 * @author CHRISTVIE MALOLO
 */

public abstract class User {
    private final  String name;
    private final String email;

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public abstract void requestTransport(); // abstract method

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}


