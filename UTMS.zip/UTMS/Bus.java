/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.christ;

/**
 *
 * @author CHRISTVIE MALOLO
 */
public class Bus implements Schedulable{
    private String registrationNumber;
    
    public Bus (String registrationNumber){
    this.registrationNumber =registrationNumber;
    }
    public String getRegistrationNumber(){
    return registrationNumber;
    }
    @Override
    public void schedule (){
        System.out.println("Bus with reg no." + registrationNumber + "Schedule." );
    }
}
