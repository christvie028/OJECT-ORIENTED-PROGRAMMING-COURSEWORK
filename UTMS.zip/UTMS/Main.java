/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.christ;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import java.sql.*;
import java.util.Scanner;

public class Main {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/utms";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "malolo2805";

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("🚗 University Transportation Management System 🚗");
            
            // User registration
            System.out.print("Enter your name: ");
            String userName = scanner.nextLine();
            int userId = saveUser(userName);
            
            if (userId == -1) {
                System.out.println("❌ Failed to register user");
                return;
            }
            
            // Display available vehicles
            System.out.println("\nAvailable Vehicles:");
            listAvailableVehicles();
            
            // Display available drivers
            System.out.println("\nAvailable Drivers:");
            listAvailableDrivers();
            
            // Request details
            System.out.print("\nEnter Vehicle ID to request: ");
            int vehicleId = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            
            System.out.print("Enter Driver ID: ");
            int driverId = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            
            System.out.print("Enter Pickup Location: ");
            String pickup = scanner.nextLine();
            
            System.out.print("Enter Destination: ");
            String destination = scanner.nextLine();
            
            // Process request
            int requestId = createTransportRequest(userId, driverId, vehicleId, pickup, destination);
            
            if (requestId != -1) {
                System.out.println("✅ Request submitted successfully! Request ID: " + requestId);
                
                // Admin approval simulation
                System.out.print("\nAdmin Action (1=Approve, 2=Reject): ");
                int action = scanner.nextInt();
                handleAdminAction(requestId, action);
            } else {
                System.out.println("❌ Failed to submit request");
            }
        }
    }
 public static void verifyDatabaseConnection() {
        System.out.println("🔌 Attempting database connection...");
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            DatabaseMetaData meta = conn.getMetaData();
            System.out.println("\n✅ CONNECTION SUCCESSFUL!");
            System.out.println("   Database: " + meta.getDatabaseProductName() + " " + meta.getDatabaseProductVersion());
            System.out.println("   Driver: " + meta.getDriverName() + " " + meta.getDriverVersion());
            System.out.println("   URL: " + meta.getURL());
        } catch (SQLException e) {
            System.out.println("\n❌ CONNECTION FAILED!");
            System.out.println("   Error: " + e.getMessage());
            System.exit(1); // Terminate application on connection failure
        }
    }

    // Save user to database
    public static int saveUser(String userName) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO users (name) VALUES (?)";
            PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, userName);
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Database error: " + e.getMessage());
        }
        return -1;
    }

    // List available vehicles
    public static void listAvailableVehicles() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT id, type, model, capacity FROM vehicles WHERE available = true";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            System.out.printf("%-5s %-10s %-15s %-10s%n", "ID", "Type", "Model", "Capacity");
            System.out.println("-----------------------------------------");
            while (rs.next()) {
                System.out.printf("%-5d %-10s %-15s %-10d%n",
                    rs.getInt("id"),
                    rs.getString("type"),
                    rs.getString("model"),
                    rs.getInt("capacity"));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error listing vehicles: " + e.getMessage());
        }
    }

    // List available drivers
    public static void listAvailableDrivers() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT id, name, license_number FROM drivers WHERE available = true";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            System.out.printf("%-5s %-20s %-15s%n", "ID", "Name", "License No");
            System.out.println("-----------------------------------------");
            while (rs.next()) {
                System.out.printf("%-5d %-20s %-15s%n",
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("license_number"));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error listing drivers: " + e.getMessage());
        }
    }

    // Create transport request
    public static int createTransportRequest(int userId, int driverId, int vehicleId, 
                                           String pickup, String destination) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Check resource availability
            if (!isResourceAvailable(conn, "drivers", driverId) || 
                !isResourceAvailable(conn, "vehicles", vehicleId)) {
                return -1;
            }
            
            // Create request
            String sql = "INSERT INTO requests (user_id, driver_id, vehicle_id, " +
                         "pickup_location, destination, status) VALUES (?, ?, ?, ?, ?, 'PENDING')";
            PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, userId);
            pstmt.setInt(2, driverId);
            pstmt.setInt(3, vehicleId);
            pstmt.setString(4, pickup);
            pstmt.setString(5, destination);
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Request creation error: " + e.getMessage());
        }
        return -1;
    }

    // Check resource availability
    private static boolean isResourceAvailable(Connection conn, String table, int id) throws SQLException {
        String sql = "SELECT available FROM " + table + " WHERE id = ? AND available = true";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (!rs.next()) {
                System.out.println("❌ Selected " + table.substring(0, table.length()-1) + " is not available");
                return false;
            }
        }
        return true;
    }

    // Admin approval handler
    public static void handleAdminAction(int requestId, int action) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String status = (action == 1) ? "APPROVED" : "REJECTED";
            String sql = "UPDATE requests SET status = ? WHERE id = ?";
            
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, status);
                pstmt.setInt(2, requestId);
                
                if (pstmt.executeUpdate() > 0) {
                    System.out.println("✅ Request status updated to: " + status);
                    
                    if (action == 1) {
                        // Mark resources as in-use
                        updateResourceStatus(conn, requestId, false);
                        System.out.println("🚕 Transportation scheduled! Driver has been notified.");
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Admin action error: " + e.getMessage());
        }
    }

    // Update resource availability status
    private static void updateResourceStatus(Connection conn, int requestId, boolean available) 
            throws SQLException {
        // Get resources from request
        String getSql = "SELECT driver_id, vehicle_id FROM requests WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(getSql)) {
            pstmt.setInt(1, requestId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                int driverId = rs.getInt("driver_id");
                int vehicleId = rs.getInt("vehicle_id");
                
                // Update driver status
                updateSingleResource(conn, "drivers", driverId, available);
                
                // Update vehicle status
                updateSingleResource(conn, "vehicles", vehicleId, available);
            }
        }
    }

    // Update single resource status
    private static void updateSingleResource(Connection conn, String table, int id, boolean available) 
            throws SQLException {
        String sql = "UPDATE " + table + " SET available = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBoolean(1, available);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
        }
    }

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("❌ MySQL Driver not found!");
            e.printStackTrace();
        }
    }
}